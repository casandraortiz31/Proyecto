package com.example.identificadordactilar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    ImageView imageViewFingerprint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imageViewFingerprint = findViewById(R.id.imageViewFingerprint);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. CONFIRMACIÓN: Mensaje para asegurar que estamos en la pantalla correcta
        Toast.makeText(this, "Abriendo Aplicación...", Toast.LENGTH_SHORT).show();

        // 2. INICIO AUTOMÁTICO: Con un pequeño retraso para evitar conflictos en Realme
        new Handler(Looper.getMainLooper()).postDelayed(this::checkAndStartBiometric, 1000);
        
        // 3. RESPALDO: Permitir activar el popup tocando el icono de huella
        imageViewFingerprint.setOnClickListener(v -> checkAndStartBiometric());
    }

    private void checkAndStartBiometric() {
        BiometricManager biometricManager = BiometricManager.from(this);
        // Compatibilidad máxima para Realme (Fuerte y Débil)
        int authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK;

        int status = biometricManager.canAuthenticate(authenticators);
        if (status == BiometricManager.BIOMETRIC_SUCCESS) {
            showBiometricPrompt(authenticators);
        } else {
            // Si el sensor no está listo, te avisará aquí con un mensaje
            handleBiometricError(status);
        }
    }

    private void showBiometricPrompt(int authenticators) {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this, executor, 
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    // Solo avisar si no fue cancelado por el usuario
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED && errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        Toast.makeText(MainActivity.this, "Error: " + errString, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    // ÉXITO: Mensaje largo para asegurar que se vea
                    Toast.makeText(getApplicationContext(), "¡Autenticación exitosa!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(MainActivity.this, homeActivity.class));
                    finish();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    // FALLO: Mensaje de error cuando la huella no coincide
                    Toast.makeText(getApplicationContext(), "Huella no reconocida, intenta nuevamente", Toast.LENGTH_LONG).show();
                }
            });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Autenticación")
                .setSubtitle("Coloca tu huella dactilar para ingresar")
                .setNegativeButtonText("Cancelar")
                .setAllowedAuthenticators(authenticators)
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void handleBiometricError(int status) {
        String message;
        switch (status) {
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                message = "No tienes huellas registradas en tu celular";
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                message = "El sensor no está disponible. Intenta desbloquear con PIN primero.";
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                message = "Este dispositivo no tiene sensor de huella";
                break;
            default:
                message = "Sensor biométrico no disponible";
                break;
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
