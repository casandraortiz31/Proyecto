<?php
    $name = $_POST['Name'];
    $age = $_POST['Age'];
    $city = $_POST['City'];
    $hobby = $_POST['Hobby'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Resultado de Datos</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="div2">
        <center>
            <h1>Resultados</h1>
            <br>
            <img src="img/Snopy.jpg" alt="Snoopy and Woodstock dressed as astronauts sitting and floating on a red doghouse roof under a starry purple sky, both appearing calm and content" width="200">
            <br>
            <?php
                echo '<p><b>Nombre:</b> '.$name.'</p><br>';
                echo '<p><b>Edad:</b> '.$age.'</p><br>';
                echo '<p><b>Ciudad:</b> '.$city.'</p><br>';
                echo '<p><b>Pasatiempo:</b> '.$hobby.'</p><br>';
            ?>
            <h2>¡Bien Hecho!</h2>  
            <div id ="popUpOverlay"></div>
            <div id="popUpBox">
                <div id="Box">
                    <i class="fas fa-question-circle fa-5x"></i>
                    <h1>¿Volver a ingresar datos?</h1>
                    <div id="closeModal"></div>
                </div>
            </div>
            <button onclick="Alert.render('You look very pretty today.')" class="btn">¡Volver a ingresar datos!</button>
            <script src="js/app.js"></script>      
        </center>
    </div>

</body>
</html>